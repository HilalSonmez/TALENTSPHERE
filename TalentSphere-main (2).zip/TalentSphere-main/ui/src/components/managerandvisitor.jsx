import React from "react";
import '../Css/register/managerandvisitor.css'

export default function ManagerandVisitor(){
    return(
        <div className="manageradnvisitor"></div>
    )
}


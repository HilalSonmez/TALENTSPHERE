package org.group3.talentsphere;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TalentSphereApplication {

    public static void main(String[] args) {
        SpringApplication.run(TalentSphereApplication.class, args);
    }

}

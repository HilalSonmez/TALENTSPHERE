package org.group3.repository.entity.enums;

public enum EGender {
    MAN, WOMAN, NO_GENDER
}

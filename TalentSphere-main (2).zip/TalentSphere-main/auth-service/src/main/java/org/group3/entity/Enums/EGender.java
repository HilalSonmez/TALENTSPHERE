package org.group3.entity.Enums;

public enum EGender {
    MAN, WOMAN, NO_GENDER
}

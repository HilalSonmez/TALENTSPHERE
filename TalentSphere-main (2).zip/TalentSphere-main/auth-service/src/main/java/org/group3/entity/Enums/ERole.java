package org.group3.entity.Enums;

public enum ERole {
    ADMIN, MANAGER, PERSONAL, VISITOR
}

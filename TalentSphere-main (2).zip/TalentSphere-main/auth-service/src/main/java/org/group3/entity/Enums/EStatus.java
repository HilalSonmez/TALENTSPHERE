package org.group3.entity.Enums;

public enum EStatus {
    ACTIVE, DELETED, PENDING, BANNED
}

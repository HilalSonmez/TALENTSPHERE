package org.group3.entity.enums;

public enum EGender {
    MAN, WOMAN, NO_GENDER
}

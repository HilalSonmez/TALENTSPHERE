package org.group3.entity.enums;

public enum EPackage {
    P_30, P_60, P_90
}

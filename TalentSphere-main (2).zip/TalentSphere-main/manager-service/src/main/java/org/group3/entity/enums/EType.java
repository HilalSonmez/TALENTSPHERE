package org.group3.entity.enums;

public enum EType {

    INCOME, EXPENSE
}

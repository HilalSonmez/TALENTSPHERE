package org.group3.entity.enums;

public enum ERole {
    ADMIN, MANAGER, PERSONAL, VISITOR
}

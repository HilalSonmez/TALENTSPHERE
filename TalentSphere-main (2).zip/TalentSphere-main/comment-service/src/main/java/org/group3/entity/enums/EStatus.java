package org.group3.entity.enums;

public enum EStatus {
ACCEPT, PENDING, REJECTED,
}

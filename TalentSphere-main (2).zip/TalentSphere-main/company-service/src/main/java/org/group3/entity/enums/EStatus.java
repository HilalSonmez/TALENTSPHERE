package org.group3.entity.enums;

public enum EStatus {

    ACTIVE, DELETED
}

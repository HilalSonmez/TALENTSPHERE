package org.group3.entity;

import org.group3.entity.enums.EStatus;

public interface IStatus {

    EStatus getStatus();

    void setStatus(EStatus status);
}

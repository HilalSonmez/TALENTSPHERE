package org.group3.utility.enums;

public enum ERole {
    ADMIN, MANAGER, PERSONAL, VISITOR
}

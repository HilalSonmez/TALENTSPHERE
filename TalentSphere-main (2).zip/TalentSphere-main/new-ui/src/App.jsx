import React from 'react';
import './App.css'
import MainPage from "./pages/MainPage.jsx";

function App() {
    return (
        <>
            <MainPage/>
        </>
    );
}

export default App;
